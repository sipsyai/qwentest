import React, { useEffect, useState, useRef } from 'react';
import { MOCK_EMBEDDING_SESSION, MOCK_VECTORS } from '../services/mockData';
import { Sparkles, BarChart2, FileText, Download, Copy, Database, ArrowLeft } from 'lucide-react';
import { useLocation } from 'react-router-dom';

const Embeddings = () => {
  const location = useLocation();
  const [inputText, setInputText] = useState(`The future of AI is multimodal.
Vector databases enable fast semantic search.
Embeddings are high-dimensional representations of data.
Machine learning models require clean datasets.`);

  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Check for incoming data from Datasets page
  useEffect(() => {
    if (location.state && location.state.initialInput) {
       setInputText(location.state.initialInput);
       // Optional: Highlight effect or scroll to textarea could go here
    }
  }, [location.state]);

  return (
    <div className="h-screen bg-slate-950 flex overflow-hidden">
      
      {/* Left Panel: Input & Config */}
      <div className="w-[500px] border-r border-slate-800 flex flex-col bg-slate-900/30">
        
        <div className="p-8 border-b border-slate-800">
           <h1 className="text-2xl font-bold text-white mb-2">Embeddings Unified UI</h1>
           <p className="text-slate-400 text-sm">Generate vector representations for semantic search and RAG.</p>
        </div>

        <div className="p-8 flex-1 flex flex-col gap-8 overflow-y-auto">
           
           <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                 <label className="text-sm font-medium text-slate-300">Embedding Model</label>
                 <div className="relative">
                    <select className="w-full bg-slate-900 border border-slate-700 text-white text-sm rounded-lg p-3 appearance-none focus:ring-2 focus:ring-blue-500 outline-none">
                      <option>nomic-embed-text</option>
                      <option>text-embedding-3-small</option>
                      <option>mxbai-embed-large</option>
                    </select>
                 </div>
              </div>
              <div className="space-y-2">
                 <label className="text-sm font-medium text-slate-300">Settings</label>
                 <div className="flex items-center justify-between bg-slate-900 border border-slate-700 p-2.5 rounded-lg">
                    <span className="text-xs text-slate-400">Truncate long input</span>
                    <div className="w-10 h-5 bg-blue-600 rounded-full relative cursor-pointer">
                      <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full"></div>
                    </div>
                 </div>
              </div>
           </div>

           <div className="flex-1 flex flex-col min-h-[300px]">
             <div className="flex justify-between items-center mb-2">
               <label className="text-sm font-medium text-slate-300">Input Text</label>
               <span className="text-xs text-slate-500">One sentence per line (or per selected object)</span>
             </div>
             <textarea 
               ref={textareaRef}
               className="flex-1 w-full bg-slate-900 border border-slate-700 rounded-xl p-4 text-sm text-slate-200 font-mono leading-relaxed resize-none focus:ring-2 focus:ring-blue-500/50 outline-none"
               value={inputText}
               onChange={(e) => setInputText(e.target.value)}
             />
           </div>

           <button className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-900/20 active:scale-[0.99]">
             <Sparkles size={18} className="fill-current" /> Generate Embeddings
           </button>

        </div>
      </div>

      {/* Right Panel: Output Explorer */}
      <div className="flex-1 bg-slate-950 flex flex-col min-w-0">
        
        <div className="h-20 border-b border-slate-800 flex items-center px-8 bg-slate-900/20">
           <div className="flex items-center gap-3 text-slate-300 font-medium">
             <BarChart2 size={20} className="text-blue-500" /> Output Explorer
           </div>
        </div>

        <div className="p-8 overflow-y-auto">
          
          {/* Session Stats */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 mb-6">
             <div className="flex justify-between items-start mb-6">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Current Session</span>
                <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Completed</span>
             </div>
             <div className="grid grid-cols-4 gap-8">
                <div>
                   <span className="text-xs text-slate-500 block mb-1">Model</span>
                   <span className="text-sm font-medium text-white">{MOCK_EMBEDDING_SESSION.model}</span>
                </div>
                <div>
                   <span className="text-xs text-slate-500 block mb-1">Dimensions</span>
                   <span className="text-sm font-medium text-white">{MOCK_EMBEDDING_SESSION.dimensions}</span>
                </div>
                <div>
                   <span className="text-xs text-slate-500 block mb-1">Tokens</span>
                   <span className="text-sm font-medium text-white">{MOCK_EMBEDDING_SESSION.tokens}</span>
                </div>
                <div>
                   <span className="text-xs text-slate-500 block mb-1">Total Vectors</span>
                   <span className="text-sm font-medium text-white">{MOCK_EMBEDDING_SESSION.totalVectors}</span>
                </div>
             </div>
          </div>

          {/* Vector List */}
          <div className="space-y-4">
             {[
               "#1: The future of AI...",
               "#2: Vector databases...",
               "#3: Embeddings are...",
               "#4: Machine learning..."
             ].map((label, idx) => (
                <div key={idx} className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                   <div className="px-4 py-3 border-b border-slate-800 flex justify-between items-center bg-slate-800/30 cursor-pointer hover:bg-slate-800/50 transition-colors">
                      <div className="flex items-center gap-3">
                         <FileText size={16} className="text-slate-500" />
                         <span className="text-sm text-slate-200 font-medium">{label}</span>
                      </div>
                      <Copy size={14} className="text-slate-500 hover:text-white" />
                   </div>
                   
                   {/* Collapsed view only shows for first item for demo */}
                   {idx === 0 && (
                     <div className="p-4">
                        <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-2">
                           {MOCK_VECTORS.map((v, vIdx) => (
                              <div key={vIdx} className="bg-slate-950 rounded border border-slate-800/50 p-2 text-center hover:border-blue-500/30 transition-colors">
                                 <span className="text-[10px] font-mono text-slate-400">{v.val.toFixed(4)}</span>
                              </div>
                           ))}
                        </div>
                        <div className="mt-3 text-right">
                           <span className="text-[10px] text-slate-500 italic">Showing first 20 of 768 values</span>
                        </div>
                     </div>
                   )}
                </div>
             ))}
          </div>

        </div>

        <div className="mt-auto border-t border-slate-800 p-4 flex justify-end">
           <button className="flex items-center gap-2 text-sm text-slate-400 hover:text-white transition-colors">
              <Download size={16} /> Export All as JSON
           </button>
        </div>

      </div>

    </div>
  );
};

export default Embeddings;
