import React, { useState, useEffect } from 'react';
import { Save, Server, ShieldCheck, RefreshCw } from 'lucide-react';
import { getBaseUrl, getApiKey, setConfig } from '../services/vllm';

const Settings = () => {
  const [url, setUrl] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');

  useEffect(() => {
    setUrl(getBaseUrl());
    setApiKey(getApiKey());
  }, []);

  const handleSave = () => {
    setConfig(url, apiKey);
    setStatus('success');
    setTimeout(() => setStatus('idle'), 2000);
  };

  return (
    <div className="p-8 h-screen overflow-y-auto bg-slate-950">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Connection Settings</h1>
        <p className="text-slate-400 text-sm">Configure your connection to the vLLM server.</p>
      </div>

      <div className="max-w-2xl space-y-6">
        {/* Connection Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-800">
            <div className="p-2 bg-blue-500/20 rounded-lg text-blue-400">
              <Server size={20} />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">vLLM Server Configuration</h3>
              <p className="text-xs text-slate-500">Target OpenAI-compatible endpoint</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Base URL</label>
              <input 
                type="text" 
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="http://localhost:8000/v1"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-3 text-sm text-white focus:ring-2 focus:ring-blue-500 outline-none font-mono"
              />
              <p className="mt-2 text-xs text-slate-500 flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                Must end with <code>/v1</code> usually. Ensure CORS is enabled on server.
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">API Key</label>
              <div className="relative">
                <ShieldCheck className="absolute left-3 top-3 text-slate-500" size={16} />
                <input 
                  type="password" 
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="EMPTY or sk-..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-10 pr-4 py-3 text-sm text-white focus:ring-2 focus:ring-blue-500 outline-none font-mono"
                />
              </div>
              <p className="mt-2 text-xs text-slate-500">
                Leave as "EMPTY" for local vLLM servers without auth.
              </p>
            </div>
          </div>

          <div className="mt-8 flex items-center justify-end gap-4">
            {status === 'success' && (
              <span className="text-emerald-400 text-sm font-medium animate-pulse">Settings Saved!</span>
            )}
            <button 
              onClick={handleSave}
              className="flex items-center gap-2 px-6 py-2.5 text-sm font-bold text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors shadow-lg shadow-blue-900/30"
            >
              <Save size={16} /> Save Configuration
            </button>
          </div>
        </div>

        {/* Info Card */}
        <div className="bg-blue-900/10 border border-blue-900/30 rounded-xl p-4 flex gap-4">
          <div className="text-blue-400 mt-1"><RefreshCw size={20} /></div>
          <div>
            <h4 className="text-blue-200 font-bold text-sm mb-1">CORS Issue?</h4>
            <p className="text-blue-300/70 text-xs leading-relaxed">
              If your browser blocks the connection, ensure you launch vLLM with:
              <br/>
              <code className="bg-blue-950/50 px-1 py-0.5 rounded border border-blue-900/50 mt-1 block w-fit">--allowed-origins="*"</code>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
