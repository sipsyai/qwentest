import React, { useState, useEffect } from 'react';
import { 
  Save, 
  Share2, 
  Info, 
  Play, 
  Zap, 
  Maximize2, 
  SlidersHorizontal,
  ThumbsUp,
  ThumbsDown,
  Copy,
  TerminalSquare,
  Sparkles,
  Loader2
} from 'lucide-react';
import { fetchVLLMModels, streamChatCompletion } from '../services/vllm';
import { Model } from '../types';

const Playground = () => {
  // State
  const [prompt, setPrompt] = useState(`Write a short poem about coding in the style of Shakespeare.`);
  const [output, setOutput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Model State
  const [availableModels, setAvailableModels] = useState<Model[]>([]);
  const [selectedModel, setSelectedModel] = useState<string>('');

  // Config
  const [thinking, setThinking] = useState(true); // Visual only for now unless using reasoning models
  const [stream, setStream] = useState(true);
  const [temperature, setTemperature] = useState(0.7);
  const [topP, setTopP] = useState(0.9);
  const [maxTokens, setMaxTokens] = useState(2048);

  // Stats
  const [startTime, setStartTime] = useState<number>(0);
  const [elapsedTime, setElapsedTime] = useState<string>('0ms');

  // Initial Load
  useEffect(() => {
    fetchVLLMModels()
      .then(models => {
        if (models.length > 0) {
          setAvailableModels(models);
          setSelectedModel(models[0].id);
        }
      })
      .catch(err => {
        console.warn("Playground failed to fetch models:", err);
        // We don't block the UI, just leave model list empty/loading state
      });
  }, []);

  const handleRun = async () => {
    if (!selectedModel) {
        setError("Please select a model first (check Settings if list is empty).");
        return;
    }

    setIsGenerating(true);
    setOutput('');
    setError(null);
    setStartTime(Date.now());
    
    // Prepare Messages
    const messages = [
        { role: "system", content: "You are a helpful AI assistant." },
        { role: "user", content: prompt }
    ];

    await streamChatCompletion(
        selectedModel,
        messages,
        { temperature, top_p: topP, max_tokens: maxTokens },
        (chunk) => {
            setOutput(prev => prev + chunk);
        },
        () => {
            setIsGenerating(false);
            setElapsedTime(((Date.now() - startTime) / 1000).toFixed(2) + 's');
        },
        (err) => {
            setError(err.message || "Failed to generate response");
            setIsGenerating(false);
        }
    );
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-950">
      {/* Center Column: Configuration & Prompt */}
      <div className="flex-1 flex flex-col border-r border-slate-800 min-w-[500px]">
        
        {/* Header */}
        <div className="h-16 border-b border-slate-800 flex items-center justify-between px-6 bg-slate-900/50 backdrop-blur-sm">
          <div className="flex items-center gap-2 text-sm text-slate-400">
            <span>Workspaces</span>
            <span className="text-slate-600">/</span>
            <span className="text-white font-medium">Generate Playground</span>
          </div>
          <div className="flex gap-3">
            <button className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-md transition-colors border border-slate-700">
              <Save size={14} /> Save Preset
            </button>
            <button className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-md transition-colors border border-slate-700">
              <Share2 size={14} /> Share
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar">
          
          {/* Model Selection */}
          <section>
            <h3 className="text-sm font-medium text-slate-400 mb-3">Model Selection</h3>
            <div className="flex gap-4">
              <div className="relative flex-1">
                <select 
                    value={selectedModel}
                    onChange={(e) => setSelectedModel(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 text-white text-sm rounded-lg p-3 appearance-none focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                >
                  {availableModels.length === 0 ? <option>Loading or No Connection...</option> : null}
                  {availableModels.map(m => (
                    <option key={m.id} value={m.id}>{m.id}</option>
                  ))}
                </select>
                <div className="absolute right-3 top-3.5 pointer-events-none text-slate-500">
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"/></svg>
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs text-blue-400 bg-blue-900/20 px-4 rounded-lg border border-blue-900/50">
                <Info size={14} />
                vLLM Backend
              </div>
            </div>
          </section>

          {/* Presets */}
          <section>
            <h3 className="text-sm font-medium text-slate-400 mb-3">Quick Presets</h3>
            <div className="flex flex-wrap gap-2">
              {['Creative Story', 'Code Refactor', 'Unit Tester', 'Data Analysis', 'SQL Query'].map((preset) => (
                <button 
                  key={preset}
                  onClick={() => setPrompt(`Acting as a ${preset}, help me with...`)}
                  className={`px-4 py-2 text-xs font-medium rounded-full border transition-colors bg-slate-900 text-slate-400 border-slate-700 hover:border-slate-500 hover:text-slate-200`}
                >
                  {preset}
                </button>
              ))}
            </div>
          </section>

          {/* User Prompt */}
          <section className="flex-1 flex flex-col min-h-[300px]">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-sm font-medium text-slate-400">User Prompt</h3>
              <span className="text-xs text-slate-500">Supports Markdown & Code Blocks</span>
            </div>
            <div className="relative flex-1">
              <textarea 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="w-full h-full min-h-[300px] bg-slate-900/50 border border-slate-700 rounded-xl p-4 text-sm text-slate-200 font-mono resize-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 outline-none custom-scrollbar leading-relaxed"
                placeholder="Enter your prompt here..."
              />
              <div className="absolute bottom-4 right-4 text-xs text-slate-500 font-mono">
                CHAR: {prompt.length} / TOKEN: ~{Math.ceil(prompt.length / 4)}
              </div>
            </div>
          </section>

          {/* Configuration Toggles */}
          <section className="bg-slate-900/50 rounded-xl p-4 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-6">
              <label className="flex items-center gap-3 cursor-pointer">
                <div className={`w-10 h-5 rounded-full relative transition-colors ${stream ? 'bg-blue-600' : 'bg-slate-700'}`} onClick={() => setStream(!stream)}>
                  <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${stream ? 'left-6' : 'left-1'}`} />
                </div>
                <span className="text-sm text-slate-300 font-medium">Stream Output</span>
              </label>
            </div>
          </section>

          {/* Model Params Sliders */}
          <section className="space-y-6 pt-4 border-t border-slate-800">
            <div className="flex items-center justify-between mb-4 cursor-pointer">
               <div className="flex items-center gap-2 text-slate-300 font-medium">
                 <SlidersHorizontal size={16} /> Model Parameters
               </div>
               <Maximize2 size={14} className="text-slate-500" />
            </div>

            <div className="grid grid-cols-2 gap-8">
              <div className="space-y-3">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Temperature</span>
                  <span className="text-blue-400 font-mono">{temperature}</span>
                </div>
                <input 
                  type="range" min="0" max="2" step="0.1" 
                  value={temperature} onChange={(e) => setTemperature(parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
              </div>

              <div className="space-y-3">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Top P</span>
                  <span className="text-blue-400 font-mono">{topP}</span>
                </div>
                <input 
                  type="range" min="0" max="1" step="0.05" 
                  value={topP} onChange={(e) => setTopP(parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
              </div>

              <div className="space-y-3">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Max Tokens</span>
                  <span className="text-blue-400 font-mono">{maxTokens}</span>
                </div>
                <input 
                  type="range" min="256" max="8192" step="256" 
                  value={maxTokens} onChange={(e) => setMaxTokens(parseInt(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
              </div>
            </div>
          </section>

          <button 
            onClick={handleRun}
            disabled={isGenerating || availableModels.length === 0}
            className={`w-full py-4 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-900/20 active:scale-[0.99] ${
                isGenerating ? 'bg-slate-700 cursor-wait' : 'bg-blue-600 hover:bg-blue-500'
            }`}
          >
            {isGenerating ? <Loader2 className="animate-spin" size={16} /> : <Play className="fill-current" size={16} />} 
            {isGenerating ? 'Stop Generation' : 'Run Configuration'}
          </button>
        </div>
      </div>

      {/* Right Column: Output */}
      <div className="w-[500px] bg-slate-925 flex flex-col border-l border-slate-800 bg-[#0B1120]">
        
        {/* Output Header */}
        <div className="h-16 border-b border-slate-800 flex items-center justify-between px-6 bg-slate-900/50 backdrop-blur-sm">
          <div className="flex items-center gap-2 text-slate-300 font-medium">
             <TerminalSquare size={18} className="text-slate-400" /> OUTPUT
          </div>
          <div className="flex items-center gap-2">
            <span className={`w-2 h-2 rounded-full ${availableModels.length > 0 ? 'bg-emerald-500' : 'bg-red-500'} ${isGenerating ? 'animate-pulse' : ''}`}></span>
            <span className="text-xs text-emerald-500 font-bold tracking-wide">{availableModels.length > 0 ? 'READY' : 'OFFLINE'}</span>
          </div>
        </div>

        {/* Output Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {error && (
            <div className="bg-red-900/20 border border-red-900/50 p-4 rounded text-red-200 text-sm">
                Error: {error}
            </div>
          )}

          {/* Response Block */}
          {(output || isGenerating) && (
            <div className="space-y-4 animate-in fade-in duration-500">
                <div className="flex items-start gap-4">
                    <div className="w-8 h-8 bg-blue-600 rounded-lg flex-shrink-0 flex items-center justify-center shadow-lg shadow-blue-900/20">
                    <Sparkles className="text-white w-4 h-4" />
                    </div>
                    <div className="space-y-4 flex-1">
                         {/* Simple Markdown-like display (preserving whitespace) */}
                         <div className="text-slate-300 text-sm leading-relaxed whitespace-pre-wrap font-sans">
                            {output}
                            {isGenerating && <span className="inline-block w-2 h-4 bg-blue-500 ml-1 animate-pulse"/>}
                         </div>
                    </div>
                </div>
            </div>
          )}
          
          {!output && !isGenerating && !error && (
            <div className="h-full flex flex-col items-center justify-center text-slate-600">
                <TerminalSquare size={48} className="mb-4 opacity-50" />
                <p className="text-sm">Ready to generate.</p>
            </div>
          )}

        </div>

        {/* Output Footer */}
        <div className="h-14 border-t border-slate-800 bg-slate-900 px-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
             <div className="flex flex-col">
               <span className="text-[10px] text-slate-500 font-bold uppercase">Length</span>
               <span className="text-xs text-slate-300 font-mono">{output.length} chars</span>
             </div>
             <div className="h-6 w-px bg-slate-800"></div>
             <div className="flex flex-col">
               <span className="text-[10px] text-slate-500 font-bold uppercase">Time</span>
               <span className="text-xs text-slate-300 font-mono">{elapsedTime}</span>
             </div>
          </div>

          <div className="flex items-center gap-2">
             <button className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-md transition-colors border border-slate-700 ml-2">
                <Copy size={14} /> Copy
             </button>
          </div>
        </div>

      </div>
    </div>
  );
};

export default Playground;
