import React from 'react';
import { MOCK_HISTORY } from '../services/mockData';
import { Search, Filter, Calendar, Trash2, ChevronRight, CheckCircle2, AlertCircle } from 'lucide-react';

const History = () => {
  return (
    <div className="p-8 h-screen overflow-y-auto bg-slate-950">
      
      <div className="mb-8">
         <h1 className="text-2xl font-bold text-white mb-2">History</h1>
         <p className="text-slate-400 text-sm">Review your recent API requests and model responses.</p>
      </div>

      {/* Filters Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 mb-6 flex flex-wrap gap-4 items-center justify-between">
         <div className="flex items-center gap-4 flex-1">
            <div className="relative flex-1 max-w-md">
               <Search className="absolute left-3 top-2.5 text-slate-500" size={16} />
               <input 
                  type="text" 
                  placeholder="Search by keyword or ID..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-10 pr-4 py-2 text-sm text-white focus:ring-2 focus:ring-blue-500 outline-none placeholder:text-slate-600"
               />
            </div>
            
            <select className="bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-sm text-slate-300 outline-none focus:border-blue-500">
               <option>Endpoint: All</option>
               <option>/v1/chat/completions</option>
               <option>/v1/embeddings</option>
            </select>

            <select className="bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-sm text-slate-300 outline-none focus:border-blue-500">
               <option>Model: All</option>
               <option>gpt-4o</option>
               <option>llama-3</option>
            </select>

             <button className="flex items-center gap-2 px-4 py-2 text-sm text-slate-300 bg-slate-950 border border-slate-700 rounded-lg hover:border-slate-500 transition-colors">
               <Calendar size={14} /> Date: Last 24 Hours
            </button>
         </div>

         <button className="px-4 py-2 text-sm text-red-400 bg-red-950/30 border border-red-900/50 rounded-lg hover:bg-red-900/50 transition-colors flex items-center gap-2">
            <Trash2 size={14} /> Clear All
         </button>
      </div>

      {/* List */}
      <div className="space-y-4">
         {MOCK_HISTORY.map((item) => (
            <div key={item.id} className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-slate-600 transition-colors cursor-pointer group">
               <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-4">
                     <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${
                        item.method === 'POST' ? 'bg-blue-500/20 text-blue-400' : 'bg-green-500/20 text-green-400'
                     }`}>
                        {item.method}
                     </span>
                     <span className="text-slate-200 font-mono text-sm font-medium">{item.endpoint}</span>
                     
                     <div className="h-4 w-px bg-slate-700 mx-2"></div>
                     
                     <span className="flex items-center gap-1.5 text-xs text-slate-400 bg-slate-800/50 px-2 py-0.5 rounded border border-slate-700/50">
                        <span className="w-1.5 h-1.5 bg-purple-500 rounded-full"></span>
                        {item.model}
                     </span>
                  </div>

                  <div className="flex items-center gap-6 text-xs text-slate-500 font-mono">
                     <span className="flex items-center gap-1.5"><Calendar size={12}/> {item.timestamp}</span>
                     <span>{item.duration}</span>
                     <span>{item.tokens} tokens</span>
                     <span className={`px-2 py-0.5 rounded-full border ${
                        item.status === 200 
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                        : 'bg-red-500/10 text-red-400 border-red-500/20'
                     }`}>
                        {item.status} {item.statusText}
                     </span>
                     <ChevronRight size={16} className="text-slate-600 group-hover:text-white transition-colors" />
                  </div>
               </div>
               
               <div className="bg-slate-950/50 rounded-lg p-3 border border-slate-800/50">
                  <p className={`text-sm font-mono truncate ${item.status !== 200 ? 'text-red-400 italic' : 'text-slate-500'}`}>
                     "{item.preview}"
                  </p>
               </div>
            </div>
         ))}
      </div>

      <div className="mt-6 flex justify-center">
         <button className="px-6 py-2 text-sm text-slate-400 border border-slate-800 rounded-lg hover:text-white hover:bg-slate-900 transition-colors">
            Load More
         </button>
      </div>

    </div>
  );
};

export default History;
