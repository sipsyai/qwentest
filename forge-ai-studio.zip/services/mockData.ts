import { Model, HistoryItem, EmbeddingSession } from '../types';

export const MOCK_MODELS: Model[] = [
  {
    id: 'llama-3-8b-instruct',
    name: 'Llama-3-8B-Instruct',
    provider: 'Meta AI',
    size: '4.7 GB',
    quantization: 'Q4_0',
    format: 'GGUF',
    lastModified: '2 days ago',
    parameters: '8.03B',
    contextWindow: 8192,
    vram: '5.43 GB',
    description: 'The Llama 3 instruction tuned model, optimized for dialogue use cases.',
    tags: ['LLAMA', 'INSTRUCT']
  },
  {
    id: 'mistral-7b',
    name: 'Mistral-7B',
    provider: 'Mistral AI',
    size: '4.2 GB',
    quantization: 'Q4_K_M',
    format: 'GGUF',
    lastModified: '1 week ago',
    parameters: '7.3B',
    contextWindow: 32768,
    vram: '4.8 GB',
    description: 'A 7-billion-parameter language model engineered for superior performance and efficiency.',
    tags: ['MISTRAL']
  },
  {
    id: 'phi-3-mini',
    name: 'Phi-3-Mini',
    provider: 'Microsoft',
    size: '2.2 GB',
    quantization: 'Q4_0',
    format: 'GGUF',
    lastModified: 'Yesterday',
    parameters: '3.8B',
    contextWindow: 4096,
    vram: '2.5 GB',
    description: 'A lightweight, state-of-the-art open model from Microsoft.',
    tags: ['PHI']
  },
  {
    id: 'codellama-7b',
    name: 'CodeLlama-7B',
    provider: 'Meta AI',
    size: '5.0 GB',
    quantization: 'Q5_K_M',
    format: 'GGUF',
    lastModified: '3 weeks ago',
    parameters: '7.0B',
    contextWindow: 16384,
    vram: '5.8 GB',
    description: 'A state-of-the-art LLM capable of generating code, and natural language about code.',
    tags: ['CODELLAMA', 'CODE']
  }
];

export const MOCK_HISTORY: HistoryItem[] = [
  {
    id: 'req_1',
    method: 'POST',
    endpoint: '/v1/chat/completions',
    model: 'gpt-4o',
    timestamp: '2024-05-20 14:22',
    duration: '420ms',
    tokens: 1240,
    status: 200,
    statusText: 'OK',
    preview: 'Merhaba! Bugün sana nasıl yardımcı olabilirim? Gelişmiş dil modellerimizle her türlü...'
  },
  {
    id: 'req_2',
    method: 'POST',
    endpoint: '/v1/images/generations',
    model: 'dall-e-3',
    timestamp: '2024-05-20 13:45',
    duration: '2.8s',
    tokens: 0,
    status: 200,
    statusText: 'OK',
    preview: 'A futuristic cyberpunk cityscape with neon lights and flying vehicles, cinematic lighting...'
  },
  {
    id: 'req_3',
    method: 'POST',
    endpoint: '/v1/chat/completions',
    model: 'gpt-4o',
    timestamp: '2024-05-20 12:10',
    duration: '110ms',
    tokens: 0,
    status: 401,
    statusText: 'Unauthorized',
    preview: 'error: { message: \'Invalid API key provided\', type: \'invalid_request_error\', param: null }'
  },
  {
    id: 'req_4',
    method: 'POST',
    endpoint: '/v1/embeddings',
    model: 'text-embedding-3',
    timestamp: '2024-05-19 23:15',
    duration: '85ms',
    tokens: 42,
    status: 200,
    statusText: 'OK',
    preview: 'The quick brown fox jumps over the lazy dog...'
  }
];

export const MOCK_EMBEDDING_SESSION: EmbeddingSession = {
  id: 'sess_1',
  model: 'nomic-embed-text',
  dimensions: 768,
  tokens: 42,
  totalVectors: 4,
  status: 'COMPLETED'
};

export const MOCK_VECTORS = [
  { val: 0.0213 }, { val: -0.1042 }, { val: 0.0967 }, { val: -0.0012 },
  { val: 0.0861 }, { val: 0.6342 }, { val: -0.0521 }, { val: 0.0123 },
  { val: 0.1102 }, { val: -0.0763 }, { val: 0.0441 }, { val: 0.0234 },
  { val: -0.5288 }, { val: 0.0672 }, { val: 0.0552 }, { val: -0.0092 },
  { val: 0.0432 }, { val: 0.0121 }, { val: -0.0345 }, { val: 0.0221 }
];
