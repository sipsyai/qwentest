import { Model } from '../types';

export const getBaseUrl = () => localStorage.getItem('forge_api_url') || 'http://localhost:8000/v1';
export const getApiKey = () => localStorage.getItem('forge_api_key') || 'EMPTY';

export const setConfig = (url: string, key: string) => {
  localStorage.setItem('forge_api_url', url);
  localStorage.setItem('forge_api_key', key);
};

// Fetch models from vLLM
export const fetchVLLMModels = async (): Promise<Model[]> => {
  const baseUrl = getBaseUrl();
  const apiKey = getApiKey();

  try {
    const response = await fetch(`${baseUrl}/models`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) throw new Error(`Server returned ${response.status} ${response.statusText}`);

    const data = await response.json();
    
    // Validate data structure
    if (!data || !data.data || !Array.isArray(data.data)) {
      console.warn("Unexpected API response format:", data);
      return [];
    }
    
    // Map OpenAI compatible format to our UI Model interface
    return data.data.map((m: any) => ({
      id: m.id,
      name: m.id,
      provider: 'vLLM Hosted',
      size: 'N/A', // vLLM API doesn't usually return disk size
      quantization: 'N/A',
      format: 'Safetensors/Pytorch',
      lastModified: new Date(m.created * 1000).toLocaleDateString(),
      parameters: 'Unknown',
      contextWindow: m.max_model_len || 8192, // vLLM often returns this in extended metadata, generic fallback
      vram: 'Dynamic',
      description: `Hosted model: ${m.object}`,
      tags: ['VLLM', 'CHAT']
    }));
  } catch (error) {
    console.error("Error fetching models:", error);
    throw error; // Propagate error to let UI handle it
  }
};

// Chat Completion Stream
export const streamChatCompletion = async (
  modelId: string,
  messages: { role: string; content: string }[],
  params: { temperature: number; top_p: number; max_tokens: number },
  onChunk: (chunk: string) => void,
  onComplete: () => void,
  onError: (err: any) => void
) => {
  const baseUrl = getBaseUrl();
  const apiKey = getApiKey();

  try {
    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: modelId,
        messages: messages,
        temperature: params.temperature,
        top_p: params.top_p,
        max_tokens: params.max_tokens,
        stream: true,
      }),
    });

    if (!response.ok) throw new Error(`API Error: ${response.statusText}`);
    if (!response.body) throw new Error('No response body');

    const reader = response.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let done = false;

    while (!done) {
      const { value, done: readerDone } = await reader.read();
      done = readerDone;
      if (value) {
        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');
        
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const jsonStr = line.slice(6);
            if (jsonStr === '[DONE]') {
              onComplete();
              return;
            }
            try {
              const json = JSON.parse(jsonStr);
              const content = json.choices[0]?.delta?.content || '';
              if (content) onChunk(content);
            } catch (e) {
              // Ignore parse errors for partial chunks
            }
          }
        }
      }
    }
    onComplete();
  } catch (error) {
    onError(error);
  }
};
